﻿using LanguageSchool.Models;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LanguageSchool.Windows
{
    /// <summary>
    /// Логика взаимодействия для AddEditServiceWindow.xaml
    /// </summary>
    public partial class AddEditServiceWindow : Window
    {
        private Service _service;
        private Entities _entities;

        public AddEditServiceWindow(Service service, Entities entities)
        {
            InitializeComponent();

            _service = service;
            _entities = entities;

            if (_service.ID != 0)
            {
                TitleInput.Text = service.Title;
                CostInput.Text = service.Cost.ToString();
                DurationInput.Text = (service.DurationInSeconds / 60).ToString();
                DescriptionInput.Text = service.Description;
                DiscountInput.Text = (service.Discount * 100).ToString();
                ImageOutput.Source = service.MainImageView;
            }
        }

        private void ApplyButton_Click(object sender, RoutedEventArgs e)
        {
            if (TitleInput.Text == string.Empty)
            {
                MessageBox.Show("Некорректное название", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (_entities.Service.Any(x => x.Title == TitleInput.Text) && _service.Title != TitleInput.Text)
            {
                MessageBox.Show("Такое название уже занято", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (CostInput.Text == string.Empty)
            {
                MessageBox.Show("Некорректная цена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            else
            {
                try
                {
                    Convert.ToDecimal(CostInput.Text);
                }
                catch
                {
                    MessageBox.Show("Некорректная цена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }

            if (DurationInput.Text == string.Empty)
            {
                MessageBox.Show("Некорректная длительность", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            else
            {
                try
                {
                    var duration = Convert.ToInt32(DurationInput.Text);
                    if (duration < 0 || duration > 240)
                    {
                        MessageBox.Show("Некорректная длительность", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }
                catch
                {
                    MessageBox.Show("Некорректная длительность", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }

            if (DiscountInput.Text == string.Empty)
            {
                MessageBox.Show("Некорректная скидка", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            else
            {
                try
                {
                    Convert.ToDouble(DiscountInput.Text);
                }
                catch
                {
                    MessageBox.Show("Некорректная скидка", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }

            _service.Title = TitleInput.Text;
            _service.Cost = Convert.ToDecimal(CostInput.Text);
            _service.DurationInSeconds = Convert.ToInt32(DurationInput.Text) * 60;
            _service.Description = DescriptionInput.Text;
            _service.Discount = Convert.ToDouble(DiscountInput.Text) / 100;

            if (ImageOutput.Source != null)
            {
                var currentDateTime = DateTime.Now;

                var file = ((BitmapImage)ImageOutput.Source).UriSource.AbsolutePath;
                file = Uri.UnescapeDataString(file);

                File.Copy(file, $"{Environment.CurrentDirectory}\\Images\\{currentDateTime.Ticks}");
                _service.MainImagePath = currentDateTime.Ticks.ToString();
            }

            if (_service.ID == 0)
            {
                _entities.Service.Add(_service);
            }

            _entities.SaveChanges();

            this.DialogResult = true;
        }

        private void DenyButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void ImageInput_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                ImageOutput.Source = new BitmapImage(new Uri(openFileDialog.FileName));
            }
        }
    }
}
