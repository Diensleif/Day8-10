﻿using LanguageSchool.Models;
using LanguageSchool.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LanguageSchool
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Entities _entities = new Entities();

        public MainWindow()
        {
            InitializeComponent();

            FilterInput.ItemsSource = new string[]
            {
                "Без фильтрации",
                "Скидка от 0% до 5%",
                "Скидка от 5% до 15%",
                "Скидка от 15% до 30%",
                "Скидка от 30% до 70%",
                "Скидка от 70% до 100%"
            };

            SortInput.ItemsSource = new string[]
            {
                "Без сортировки",
                "По возрастанию цены",
                "По убыванию цены"
            };

            RefreshServices(SearchInput.Text, FilterInput.Text, SortInput.Text);
        }

        private void AdminModeButton_Click(object sender, RoutedEventArgs e)
        {
            if (_adminMode)
            {
                _adminMode  = false;
                AddButton.Visibility = Visibility.Collapsed;
                RefreshServices(SearchInput.Text, FilterInput.Text, SortInput.Text);
            }
            else
            {
                var adminModeWindow = new AdminModeWindow();
                if (adminModeWindow.ShowDialog() == true)
                {
                    _adminMode = true;
                    AddButton.Visibility = Visibility.Visible;
                    RefreshServices(SearchInput.Text, FilterInput.Text, SortInput.Text);
                }
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var addEditServiceWindow = new AddEditServiceWindow(new Service(), _entities);
            if (addEditServiceWindow.ShowDialog() == true)
            {
                RefreshServices(SearchInput.Text, FilterInput.Text, SortInput.Text);
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var service = ((sender as Button).DataContext as Service);

            var addEditServiceWindow = new AddEditServiceWindow(service, _entities);
            if (addEditServiceWindow.ShowDialog() == true)
            {
                RefreshServices(SearchInput.Text, FilterInput.Text, SortInput.Text);
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите удалить эту запись?",
                "Внимание",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning) == MessageBoxResult.No)
            {
                return;
            }

            var service = ((sender as Button).DataContext as Service);

            _entities.Service.Remove(service);
            _entities.SaveChanges();

            RefreshServices(SearchInput.Text, FilterInput.Text, SortInput.Text);
        }

        private bool _adminMode = false;

        private void RefreshServices(string search, string filter, string sort)
        {
            var services = _entities.Service.AsEnumerable();

            if (!string.IsNullOrEmpty(search))
            {
                services = services.Where(x => x.Title.Contains(search));
            }

            switch (filter)
            {
                case "Скидка от 0% до 5%":
                    services = services.Where(x => x.Discount >= 0 && x.Discount < 0.05);
                    break;
                case "Скидка от 5% до 15%":
                    services = services.Where(x => x.Discount >= 0.05 && x.Discount < 0.15);
                    break;
                case "Скидка от 15% до 30%":
                    services = services.Where(x => x.Discount >= 0.15 && x.Discount < 0.3);
                    break;
                case "Скидка от 30% до 70%":
                    services = services.Where(x => x.Discount >= 0.3 && x.Discount < 0.7);
                    break;
                case "Скидка от 70% до 100%":
                    services = services.Where(x => x.Discount >= 0.7 && x.Discount < 1);
                    break;
            }

            switch (sort)
            {
                case "По возрастанию цены":
                    services = services.OrderBy(x => x.Cost * (decimal)(1 - x.Discount));
                    break;
                case "По убыванию цены":
                    services = services.OrderByDescending(x => x.Cost * (decimal)(1 - x.Discount));
                    break;
            }

            if (_adminMode)
            {
                foreach (var service in services)
                {
                    service.VisibilityView = Visibility.Visible;
                }
            }

            CountOutput.Text = $"Найдено {services.Count()} из {_entities.Service.Count()}";
            Services.ItemsSource = services.ToList();
        }

        private void SearchInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            RefreshServices(SearchInput.Text, FilterInput.Text, SortInput.Text);
        }

        private void FilterInput_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshServices(SearchInput.Text, e.AddedItems[0] as string, SortInput.Text);
        }

        private void SortInput_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshServices(SearchInput.Text, FilterInput.Text, e.AddedItems[0] as string);
        }
    }
}
